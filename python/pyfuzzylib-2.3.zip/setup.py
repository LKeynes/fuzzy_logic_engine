from setuptools import setup, find_packages
setup(
    name = "pyfuzzylib",
    version = "2.3",
    license="LGPL",
    packages = find_packages(),
    author = "Dott. Monselice Diego",
    author_email='diegomonselice@gmail.com',
    url= 'http://sourceforge.net/projects/pyfuzzylib',
    include_package_data=True
)
