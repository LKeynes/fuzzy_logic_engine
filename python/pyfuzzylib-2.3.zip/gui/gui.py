# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'untitled.ui'
#
# Created: Mon Oct 15 15:26:16 2012
#      by: PyQt4 UI code generator 4.8.5
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui
from pyfuzzylib.engine import *


try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Expert_system(object):
    def setupUi(self, Expert_system):
        Expert_system.setObjectName(_fromUtf8("Expert_system"))
        Expert_system.resize(1024, 768)
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Arial"))
        Expert_system.setFont(font)
        Expert_system.setWindowTitle(QtGui.QApplication.translate("Expert_system", "{0} - Expert System".format(eng.name), None, QtGui.QApplication.UnicodeUTF8))
        self.centralwidget = QtGui.QWidget(Expert_system)
        self.centralwidget.setObjectName(_fromUtf8("centralwidget"))
        self.groupBox = QtGui.QGroupBox(self.centralwidget)
        self.groupBox.setGeometry(QtCore.QRect(20, 170, 441, 571))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Arial"))
        self.groupBox.setFont(font)
        self.groupBox.setTitle(QtGui.QApplication.translate("Expert_system", "Inputs", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.scrollArea = QtGui.QScrollArea(self.groupBox)
        self.scrollArea.setGeometry(QtCore.QRect(10, 20, 421, 531))
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName(_fromUtf8("scrollArea"))
        self.scrollAreaWidgetContents = QtGui.QWidget()
        self.scrollAreaWidgetContents.setGeometry(QtCore.QRect(0, 0, 419, 529))
        self.scrollAreaWidgetContents.setObjectName(_fromUtf8("scrollAreaWidgetContents"))
        self.lineEdits = []
        self.labels = []
        x = 10
        y = 20
        for i in eng.inputList():
            self.lineEdits.append(QtGui.QLineEdit(self.scrollAreaWidgetContents))
            self.lineEdits[len(self.lineEdits)-1].setGeometry(QtCore.QRect(x+150, y, 113, 27))
            self.lineEdits[len(self.lineEdits)-1].setObjectName(_fromUtf8(i))
            QtCore.QObject.connect(self.lineEdits[len(self.lineEdits)-1], QtCore.SIGNAL(_fromUtf8("returnPressed()")), self.results)
            if len(self.lineEdits)>1:
                Expert_system.setTabOrder(self.lineEdits[len(self.lineEdits)-2], self.lineEdits[len(self.lineEdits)-1])
            
            self.labels.append(QtGui.QLabel(self.scrollAreaWidgetContents))
            self.labels[len(self.labels)-1].setGeometry(QtCore.QRect(x, y, 130, 17))
            self.labels[len(self.labels)-1].setText(QtGui.QApplication.translate("Expert_system", i, None, QtGui.QApplication.UnicodeUTF8))
            self.labels[len(self.labels)-1].setObjectName(_fromUtf8(i))
            y+=50
        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.line = QtGui.QFrame(self.centralwidget)
        self.line.setGeometry(QtCore.QRect(20, 150, 991, 20))
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.label_3 = QtGui.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(20, 10, 431, 41))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Arial"))
        font.setPointSize(28)
        self.label_3.setFont(font)
        self.label_3.setText(QtGui.QApplication.translate("Expert_system", eng.name, None, QtGui.QApplication.UnicodeUTF8))
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.textBrowser = QtGui.QTextBrowser(self.centralwidget)
        self.textBrowser.setGeometry(QtCore.QRect(20, 60, 1001, 91))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Arial"))
        self.textBrowser.setFont(font)
        self.textBrowser.setHtml(QtGui.QApplication.translate("Expert_system", eng.description, None, QtGui.QApplication.UnicodeUTF8))
        self.textBrowser.setObjectName(_fromUtf8("textBrowser"))
        self.pushButton = QtGui.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(650, 200, 231, 91))
        self.pushButton.setText(QtGui.QApplication.translate("Expert_system", "RUN", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        QtCore.QObject.connect(self.pushButton, QtCore.SIGNAL(_fromUtf8("clicked()")), self.results)
        self.groupBox_2 = QtGui.QGroupBox(self.centralwidget)
        self.groupBox_2.setGeometry(QtCore.QRect(530, 340, 441, 391))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Arial"))
        self.groupBox_2.setFont(font)
        self.groupBox_2.setTitle(QtGui.QApplication.translate("Expert_system", "Results", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.textOutput = QtGui.QTextBrowser(self.groupBox_2)
        self.textOutput.setGeometry(QtCore.QRect(20, 60, 1001, 91))
        self.textOutput.setFont(font)
        #self.textOutput.setHtml(QtGui.QApplication.translate("Expert_system", "questa<br>e'<br>una<br>prova", None, QtGui.QApplication.UnicodeUTF8))
        self.textOutput.setObjectName(_fromUtf8("textBrowser"))
        
        Expert_system.setCentralWidget(self.centralwidget)
        self.statusbar = QtGui.QStatusBar(Expert_system)
        self.statusbar.setObjectName(_fromUtf8("statusbar"))
        Expert_system.setStatusBar(self.statusbar)

        self.retranslateUi(Expert_system)
        QtCore.QMetaObject.connectSlotsByName(Expert_system)

    def results(self, out=None):
        inputs = {}
        input_vars = eng.inputList()
        #try:
        for i in range(len(input_vars)):
            inputs[input_vars[i]] = self.lineEdits[i].text()
            print "{0}: {1}".format(input_vars[i],self.lineEdits[i].text())
        out_dict = eng.run(inputs)
        out_string = "<ul>"
        print "ok"
        for k in out_dict.keys():
            out_string += "<li>{0}:{1}<ul>".format(k,str(out_dict[k]))
            degrees = eng.variables[k].get_degrees(out_dict[k])
            sorted_degrees = degrees.keys()
            print sorted_degrees
            sorted_degrees.sort(key=lambda x:degrees[x])
            sorted_degrees.reverse()
            print sorted_degrees
            for d in sorted_degrees:
                if degrees[d]:
                    out_string += "<li>{0}: {1}</li>".format(d,degrees[d])
            out_string +="</ul></li>"
        out_string += "</ul>"
        self.textOutput.setHtml(QtGui.QApplication.translate("Expert_system", out_string, None, QtGui.QApplication.UnicodeUTF8))
        print out_string
        """
        except Exception,exc:
            print exc
        """
    def retranslateUi(self, Expert_system):
        pass

if __name__=="__main__":
    import sys
    if len(sys.argv)>1:
        filename = sys.argv[1]
    else:
        filename = "engine_string.dll"
    f = open(filename,"r")
    stringa = f.read()
    print stringa
    f.close()
    eng = FuzzyEngine()
    eng.import_from_string(stringa)
    app = QtGui.QApplication(sys.argv)
    window = Ui_Expert_system()
    Expert_system = QtGui.QMainWindow()
    window.setupUi(Expert_system)
    Expert_system.show()
    #window.results()
    sys.exit(app.exec_())
