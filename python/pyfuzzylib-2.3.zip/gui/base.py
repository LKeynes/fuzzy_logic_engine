# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'untitled.ui'
#
# Created: Tue Oct 16 08:49:51 2012
#      by: PyQt4 UI code generator 4.8.5
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Expert_system(object):
    def setupUi(self, Expert_system):
        Expert_system.setObjectName(_fromUtf8("Expert_system"))
        Expert_system.resize(1024, 768)
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Arial"))
        Expert_system.setFont(font)
        Expert_system.setWindowTitle(QtGui.QApplication.translate("Expert_system", "pyFuzzyLib Expert System", None, QtGui.QApplication.UnicodeUTF8))
        self.centralwidget = QtGui.QWidget(Expert_system)
        self.centralwidget.setObjectName(_fromUtf8("centralwidget"))
        self.groupBox = QtGui.QGroupBox(self.centralwidget)
        self.groupBox.setGeometry(QtCore.QRect(20, 170, 441, 571))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Arial"))
        self.groupBox.setFont(font)
        self.groupBox.setTitle(QtGui.QApplication.translate("Expert_system", "Inputs", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.scrollArea = QtGui.QScrollArea(self.groupBox)
        self.scrollArea.setGeometry(QtCore.QRect(10, 20, 421, 531))
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName(_fromUtf8("scrollArea"))
        self.scrollAreaWidgetContents = QtGui.QWidget()
        self.scrollAreaWidgetContents.setGeometry(QtCore.QRect(0, 0, 419, 529))
        self.scrollAreaWidgetContents.setObjectName(_fromUtf8("scrollAreaWidgetContents"))
        self.lineEdit = QtGui.QLineEdit(self.scrollAreaWidgetContents)
        self.lineEdit.setGeometry(QtCore.QRect(130, 10, 113, 27))
        self.lineEdit.setObjectName(_fromUtf8("lineEdit"))
        self.label = QtGui.QLabel(self.scrollAreaWidgetContents)
        self.label.setGeometry(QtCore.QRect(10, 20, 67, 17))
        self.label.setText(QtGui.QApplication.translate("Expert_system", "TextLabel", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setObjectName(_fromUtf8("label"))
        self.label_2 = QtGui.QLabel(self.scrollAreaWidgetContents)
        self.label_2.setGeometry(QtCore.QRect(10, 70, 67, 17))
        self.label_2.setText(QtGui.QApplication.translate("Expert_system", "TextLabel", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.lineEdit_2 = QtGui.QLineEdit(self.scrollAreaWidgetContents)
        self.lineEdit_2.setGeometry(QtCore.QRect(130, 60, 113, 27))
        self.lineEdit_2.setObjectName(_fromUtf8("lineEdit_2"))
        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.line = QtGui.QFrame(self.centralwidget)
        self.line.setGeometry(QtCore.QRect(20, 150, 991, 20))
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.label_3 = QtGui.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(20, 10, 431, 41))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Arial"))
        font.setPointSize(28)
        self.label_3.setFont(font)
        self.label_3.setText(QtGui.QApplication.translate("Expert_system", "Expert System Name", None, QtGui.QApplication.UnicodeUTF8))
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.textBrowser = QtGui.QTextBrowser(self.centralwidget)
        self.textBrowser.setGeometry(QtCore.QRect(20, 60, 1001, 91))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Arial"))
        self.textBrowser.setFont(font)
        self.textBrowser.setHtml(QtGui.QApplication.translate("Expert_system", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'Arial\'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'Ubuntu\';\">Description</span></p></body></html>", None, QtGui.QApplication.UnicodeUTF8))
        self.textBrowser.setObjectName(_fromUtf8("textBrowser"))
        self.pushButton = QtGui.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(650, 200, 231, 91))
        self.pushButton.setText(QtGui.QApplication.translate("Expert_system", "RUN", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.groupBox_2 = QtGui.QGroupBox(self.centralwidget)
        self.groupBox_2.setGeometry(QtCore.QRect(530, 340, 441, 391))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Arial"))
        self.groupBox_2.setFont(font)
        self.groupBox_2.setTitle(QtGui.QApplication.translate("Expert_system", "Results", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.scrollArea_2 = QtGui.QScrollArea(self.groupBox_2)
        self.scrollArea_2.setGeometry(QtCore.QRect(10, 20, 421, 361))
        self.scrollArea_2.setWidgetResizable(True)
        self.scrollArea_2.setObjectName(_fromUtf8("scrollArea_2"))
        self.scrollAreaWidgetContents_2 = QtGui.QWidget()
        self.scrollAreaWidgetContents_2.setGeometry(QtCore.QRect(0, 0, 419, 359))
        self.scrollAreaWidgetContents_2.setObjectName(_fromUtf8("scrollAreaWidgetContents_2"))
        self.lineEdit_3 = QtGui.QLineEdit(self.scrollAreaWidgetContents_2)
        self.lineEdit_3.setGeometry(QtCore.QRect(130, 10, 113, 27))
        self.lineEdit_3.setReadOnly(True)
        self.lineEdit_3.setObjectName(_fromUtf8("lineEdit_3"))
        self.label_4 = QtGui.QLabel(self.scrollAreaWidgetContents_2)
        self.label_4.setGeometry(QtCore.QRect(10, 20, 67, 17))
        self.label_4.setText(QtGui.QApplication.translate("Expert_system", "TextLabel", None, QtGui.QApplication.UnicodeUTF8))
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.label_5 = QtGui.QLabel(self.scrollAreaWidgetContents_2)
        self.label_5.setGeometry(QtCore.QRect(10, 70, 67, 17))
        self.label_5.setText(QtGui.QApplication.translate("Expert_system", "TextLabel", None, QtGui.QApplication.UnicodeUTF8))
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.lineEdit_4 = QtGui.QLineEdit(self.scrollAreaWidgetContents_2)
        self.lineEdit_4.setGeometry(QtCore.QRect(130, 60, 113, 27))
        self.lineEdit_4.setReadOnly(True)
        self.lineEdit_4.setObjectName(_fromUtf8("lineEdit_4"))
        self.scrollArea_2.setWidget(self.scrollAreaWidgetContents_2)
        Expert_system.setCentralWidget(self.centralwidget)
        self.statusbar = QtGui.QStatusBar(Expert_system)
        self.statusbar.setObjectName(_fromUtf8("statusbar"))
        Expert_system.setStatusBar(self.statusbar)

        self.retranslateUi(Expert_system)
        QtCore.QObject.connect(self.lineEdit, QtCore.SIGNAL(_fromUtf8("returnPressed()")), self.pushButton.toggle)
        QtCore.QObject.connect(self.pushButton, QtCore.SIGNAL(_fromUtf8("clicked()")), self.textBrowser.copy)
        QtCore.QObject.connect(self.lineEdit_2, QtCore.SIGNAL(_fromUtf8("returnPressed()")), self.pushButton.toggle)
        QtCore.QMetaObject.connectSlotsByName(Expert_system)
        Expert_system.setTabOrder(self.lineEdit, self.lineEdit_2)
        Expert_system.setTabOrder(self.lineEdit_2, self.pushButton)
        Expert_system.setTabOrder(self.pushButton, self.scrollArea_2)
        Expert_system.setTabOrder(self.scrollArea_2, self.lineEdit_3)
        Expert_system.setTabOrder(self.lineEdit_3, self.lineEdit_4)
        Expert_system.setTabOrder(self.lineEdit_4, self.textBrowser)
        Expert_system.setTabOrder(self.textBrowser, self.scrollArea)

    def retranslateUi(self, Expert_system):
        pass

